import cv2
import mediapipe as mp
import numpy as np

mp_pose = mp.solutions.pose

def calculate_angle(a, b, c):
    a = np.array(a)
    b = np.array(b)
    c = np.array(c)

    radians = np.arctan2(c[1]-b[1], c[0]-b[0]) - np.arctan2(a[1]-b[1], a[0]-b[0])
    angle = np.abs(radians * 180.0 / np.pi)
    if angle > 180.0:
        angle = 360 - angle
    return angle

def extract_pose_metrics(video_path):
    cap = cv2.VideoCapture(video_path)
    pose = mp_pose.Pose()
    
    left_knee_angles = []
    right_knee_angles = []
    spine_tilts = []

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        img_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = pose.process(img_rgb)
        if not results.pose_landmarks:
            continue

        lm = results.pose_landmarks.landmark

        hip_l = [lm[mp_pose.PoseLandmark.LEFT_HIP].x, lm[mp_pose.PoseLandmark.LEFT_HIP].y]
        knee_l = [lm[mp_pose.PoseLandmark.LEFT_KNEE].x, lm[mp_pose.PoseLandmark.LEFT_KNEE].y]
        ankle_l = [lm[mp_pose.PoseLandmark.LEFT_ANKLE].x, lm[mp_pose.PoseLandmark.LEFT_ANKLE].y]

        hip_r = [lm[mp_pose.PoseLandmark.RIGHT_HIP].x, lm[mp_pose.PoseLandmark.RIGHT_HIP].y]
        knee_r = [lm[mp_pose.PoseLandmark.RIGHT_KNEE].x, lm[mp_pose.PoseLandmark.RIGHT_KNEE].y]
        ankle_r = [lm[mp_pose.PoseLandmark.RIGHT_ANKLE].x, lm[mp_pose.PoseLandmark.RIGHT_ANKLE].y]

        shoulder = [lm[mp_pose.PoseLandmark.LEFT_SHOULDER].x, lm[mp_pose.PoseLandmark.LEFT_SHOULDER].y]
        hip_mid = [(hip_l[0] + hip_r[0]) / 2, (hip_l[1] + hip_r[1]) / 2]

        left_knee_angle = calculate_angle(hip_l, knee_l, ankle_l)
        right_knee_angle = calculate_angle(hip_r, knee_r, ankle_r)
        spine_tilt = calculate_angle(shoulder, hip_mid, [hip_mid[0], hip_mid[1] + 0.1])

        left_knee_angles.append(left_knee_angle)
        right_knee_angles.append(right_knee_angle)
        spine_tilts.append(spine_tilt)

    cap.release()
    pose.close()

    return {
        "left_knee_flexion": round(np.mean(left_knee_angles), 2),
        "right_knee_flexion": round(np.mean(right_knee_angles), 2),
        "spine_tilt": round(np.mean(spine_tilts), 2)
    }
