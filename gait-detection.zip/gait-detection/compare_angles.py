import json
import os

# Load angles for a specific patient session (previous or current)
def load_angles(patient_id, session_type="previous"):
    """Load angles for a specific session (previous or current)."""
    file_name = f"data/{patient_id}_{session_type}_angles.json"
    
    if not os.path.exists(file_name):
        print(f"Warning: {file_name} not found!")
        return {}

    with open(file_name, "r") as f:
        return json.load(f)

# Helper function to format joint names properly
def format_joint_name(joint):
    return joint.replace('_', ' ').title()

# Function to compare angles of a joint
def compare_joint_angles(joint, angles_previous, angles_current):
    """Compare angles of a specific joint between previous and current sessions."""
    angle_previous = angles_previous.get(joint, None)
    angle_current = angles_current.get(joint, None)
    
    # Handle missing data
    if angle_previous is None:
        return f"❌ No previous data for {format_joint_name(joint)}"
    
    if angle_current is None:
        return f"❌ No current data for {format_joint_name(joint)}"

    # Compute the difference
    angle_diff = angle_current - angle_previous
    # Compute percentage change
    percentage_change = ((angle_diff / angle_previous) * 100) if angle_previous != 0 else 0

    # Determine improvement or worsening based on angle difference
    if angle_diff > 5:
        return f"✅ Improved {format_joint_name(joint)} by {angle_diff:.2f}° ({percentage_change:.2f}%)"
    elif angle_diff < -5:
        return f"❌ Worsened {format_joint_name(joint)} by {abs(angle_diff):.2f}° ({abs(percentage_change):.2f}%)"
    else:
        return f"➖ No significant change in {format_joint_name(joint)}"

# Function to generate comparison report for a patient
def generate_patient_report(patient_id):
    """Generate detailed comparison report for a patient."""
    # Load angles for both previous and current sessions
    angles_previous = load_angles(patient_id, session_type="previous")
    angles_current = load_angles(patient_id, session_type="current")

    # Check if data is missing for either session
    if not angles_previous or not angles_current:
        print(f"Error: Missing data for patient {patient_id}. Skipping report generation.")
        return

    print(f"Generating comparison report for Patient ID: {patient_id}\n")

    # Iterate over all joints in previous session and compare angles
    for joint in angles_previous.keys():
        print(compare_joint_angles(joint, angles_previous, angles_current))

# Example usage: Generate comparison report for patient with ID "patient_001"
generate_patient_report("patient_001")
